package com.example.myfirstapp;

public class UerActivity {
}
